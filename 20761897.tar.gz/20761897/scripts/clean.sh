rm *.cnf assign.txt solution.txt stat.txt
make clean
