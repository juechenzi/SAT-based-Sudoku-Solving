make
./produce_solution.sh
